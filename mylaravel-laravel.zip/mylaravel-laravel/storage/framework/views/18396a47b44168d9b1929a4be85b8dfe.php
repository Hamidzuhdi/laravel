<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link rel="stylesheet" href="gaya/style-welcome.css">
</head>
<body>
    <h3>SELAMAT DATANG</h3>
    <a href='/login'>
        <img src="gambar/ukmsepak.jpeg" alt="ukm">
    </a>
</body>
</html><?php /**PATH C:\app\mylaravel-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>